
import re, sys, hashlib, os

FROZEN_START = re.compile(r'^\s*#\s*={5,}\s*FROZEN\s+START\s*={5,}\s*$', re.I|re.M)
FROZEN_END   = re.compile(r'^\s*#\s*={5,}\s*FROZEN\s+END\s*={5,}\s*$', re.I|re.M)
MOD_START    = re.compile(r'^\s*#\s*={5,}\s*MODULAR\s+START\s*={5,}\s*$', re.I|re.M)
MOD_END      = re.compile(r'^\s*#\s*={5,}\s*MODULAR\s+END\s*={5,}\s*$', re.I|re.M)

FOOT_FROZEN  = re.compile(r'^\s*#?\s*FROZEN_SHA256\s*:\s*([0-9a-f]{64})\s*$', re.I|re.M)
FOOT_MOD     = re.compile(r'^\s*#?\s*MODULAR_SHA256\s*:\s*([0-9a-f]{64})\s*$', re.I|re.M)
FOOT_FILE    = re.compile(r'^\s*#?\s*FILE_SHA256\s*:\s*([0-9a-f]{64})\s*$', re.I|re.M)

def sha(s): 
    h=hashlib.sha256(); h.update(s.encode('utf-8')); return h.hexdigest()

path = sys.argv[1] if len(sys.argv)>1 else r'/mnt/data/FASTALL_OperativeOnly_Pagination_PATCH4c_HARDGET_FIX4_MODv3.py'
with open(path, 'r', encoding='utf-8') as f:
    t = f.read()

def span(text, a, b, label):
    sa = list(a.finditer(text)); sb = list(b.finditer(text))
    if len(sa) != 1 or len(sb) != 1:
        print(f"[FAIL] {label} markers: expected 1/1, found {len(sa)}/{len(sb)}")
        sys.exit(2)
    s = sa[0].end(); e = sb[0].start()
    if e < s:
        print(f"[FAIL] {label} markers inverted/overlap")
        sys.exit(2)
    return text[s:e]

frozen = span(t, FROZEN_START, FROZEN_END, "FROZEN")
mod    = span(t, MOD_START, MOD_END, "MODULAR")

if not frozen.strip():
    print("[FAIL] FROZEN block empty"); sys.exit(2)
if not mod.strip():
    print("[FAIL] MODULAR block empty"); sys.exit(2)

calc_frozen = sha(frozen)
calc_mod    = sha(mod)
file_wo_filehash = re.sub(FOOT_FILE, "", t)
calc_file   = hashlib.sha256(file_wo_filehash.encode('utf-8')).hexdigest()

m_frozen = FOOT_FROZEN.search(t)
m_mod    = FOOT_MOD.search(t)
m_file   = FOOT_FILE.search(t)

print(f"Frozen SHA256 (calc):  {calc_frozen}")
print(f"Modular SHA256 (calc): {calc_mod}")
print(f"File   SHA256 (calc):  {calc_file}")

if m_frozen: print(f"Frozen SHA256 (foot):  {m_frozen.group(1)}")
if m_mod:    print(f"Modular SHA256 (foot): {m_mod.group(1)}")
if m_file:   print(f"File   SHA256 (foot):  {m_file.group(1)}")

ok = True
if m_frozen and m_frozen.group(1).lower()!=calc_frozen.lower(): ok=False
if m_mod    and m_mod.group(1).lower()!=calc_mod.lower():       ok=False
if m_file   and m_file.group(1).lower()!=calc_file.lower():     ok=False

print("[RESULT]: OK" if ok else "[RESULT]: FAIL")
