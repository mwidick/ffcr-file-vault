
FFCR MODv3 Transfer — Ready-to-Run
==================================

Files included (this download):
  - FASTALL_OperativeOnly_Pagination_PATCH4c_HARDGET_FIX4_MODv3.py
  - verify_hashes.py
  - Run_FASTALL_OperativeOnly_Patch4c_HardGET_FIX4_MODv3.bat
  - sha256_manifest_template.txt
  - README-TRANSFER.txt

Quick verify:
  1) Open Command Prompt in this folder
  2) python verify_hashes.py
     → Expect [RESULT]: OK (non-empty blocks; footer matches)

Launch:
  - Double-click Run_FASTALL_OperativeOnly_Patch4c_HardGET_FIX4_MODv3.bat
    or:  python FASTALL_OperativeOnly_Pagination_PATCH4c_HARDGET_FIX4_MODv3.py

Notes:
  - Frozen block remains untouched.
  - Footer lines are updated to the exact SHA-256 of Frozen/Modular and of the file (with FILE line normalized).
  - If validator reports FAIL, please paste its full output.
