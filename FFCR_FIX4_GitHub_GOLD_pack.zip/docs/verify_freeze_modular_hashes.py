import re, hashlib, sys

FROZEN_START = "# ========= FROZEN START ========="
FROZEN_END   = "# ========= FROZEN END ========="
MOD_START    = "# ========= MODULAR START ========="
MOD_END      = "# ========= MODULAR END ========="

CANON_FULL    = "633b3586ebf94cab358d4a68fac0f535b87ca095b8d9f26741628c3bcb4e75d3"
CANON_FROZEN  = "77c6fdaaf61f311da53e0793c710a96daaf4b0b0a953c68ef8d250f716226e9e"
CANON_MODULAR = "77c6fdaaf61f311da53e0793c710a96daaf4b0b0a953c68ef8d250f716226e9e"

TARGET_FILE = "FASTALL_OperativeOnly_Pagination_MARKED_patched(4)_PATCH4c_HARDGET_FIX4.py"

def sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def main():
    try:
        with open(TARGET_FILE, "r", encoding="utf-8") as f:
            src = f.read()
    except Exception as e:
        print(f"[VERIFY] ERROR opening {TARGET_FILE}: {e}")
        sys.exit(2)

    full = sha256(src)
    mf = re.search(re.escape(FROZEN_START)+"(.*?)"+re.escape(FROZEN_END), src, re.S)
    mm = re.search(re.escape(MOD_START)+"(.*?)"+re.escape(MOD_END), src, re.S)
    frozen  = sha256(mf.group(1) if mf else "")
    modular = sha256(mm.group(1) if mm else "")

    print("[VERIFY] Full    :", full)
    print("[VERIFY] Frozen  :", frozen)
    print("[VERIFY] Modular :", modular)

    ok = True
    if full != CANON_FULL:
        print(f"[VERIFY] FULL MISMATCH: expected {CANON_FULL}")
        ok = False
    if frozen != CANON_FROZEN:
        print(f"[VERIFY] FROZEN MISMATCH: expected {CANON_FROZEN}")
        ok = False
    if modular != CANON_MODULAR:
        print(f"[VERIFY] MODULAR MISMATCH: expected {CANON_MODULAR}")
        ok = False

    if ok:
        print("[VERIFY] OK — all hashes match canonical.")
        return 0
    else:
        print("[VERIFY] FAIL — one or more mismatches.")
        return 1

if __name__ == "__main__":
    sys.exit(main())