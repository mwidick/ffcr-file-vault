# FFCR FIX4 — Gold Standard (GitHub-ready)

This package preserves the **exact files** you confirmed working (no edits). It also includes a verifier that
checks the full file, frozen section, and modular section hashes.

## Structure
```
src/FASTALL_OperativeOnly_Pagination_MARKED_patched(4)_PATCH4c_HARDGET_FIX4.py
tools/Run_FFCR_Fix4_GOLD.bat
docs/verify_freeze_modular_hashes.py
docs/README.md
SECURITY_MANIFEST.json
```

## Canonical checksums (from your gold Python file)
- Full file: `633b3586ebf94cab358d4a68fac0f535b87ca095b8d9f26741628c3bcb4e75d3`
- Frozen    : `77c6fdaaf61f311da53e0793c710a96daaf4b0b0a953c68ef8d250f716226e9e`
- Modular   : `77c6fdaaf61f311da53e0793c710a96daaf4b0b0a953c68ef8d250f716226e9e`

## How to run (Windows)
1. Copy `src/FASTALL_OperativeOnly_Pagination_MARKED_patched(4)_PATCH4c_HARDGET_FIX4.py` and `tools/Run_FFCR_Fix4_GOLD.bat` into `C:\FFCR_Project\Attachments_Multiple\`
2. Double-click `tools/Run_FFCR_Fix4_GOLD.bat`

## How to verify in repo root
```
cd src
python ../docs/verify_freeze_modular_hashes.py
```
The script prints all three hashes and returns non-zero if any mismatch.
