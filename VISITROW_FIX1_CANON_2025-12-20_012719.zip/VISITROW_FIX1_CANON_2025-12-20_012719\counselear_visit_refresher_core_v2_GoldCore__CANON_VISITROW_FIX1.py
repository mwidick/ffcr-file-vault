# =======================================================================
# FROZEN SECTION (BWMoC): SafeCore driver setup + basic environment
# Do not modify without explicit authorization.
# =======================================================================

from __future__ import annotations

import csv
import os
import re
import sys
import time
from dataclasses import dataclass
from typing import List, Optional, Tuple
from urllib.parse import urljoin

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException

def setup_driver() -> webdriver.Chrome:
    """
    Create and return a Chrome WebDriver using the same SafeCore/Selenium
    environment that already works for your Patient Activity scripts.
    """
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-infobars")
    options.add_argument("--disable-gpu")

    # SafeCore injector hooks the correct chrome.exe & chromedriver
    driver = webdriver.Chrome(options=options)
    driver.implicitly_wait(5)
    return driver

# =======================================================================
# MODULAR SECTION: Canon Visit Grid -> Visit Edit -> Save -> Back loop
# Implements CounselEar_VisitGrid_CANON_FLOW.md / CANON_SPEC.md selectors.
# =======================================================================

# ---- Canon selectors (do not "optimize") ----
PATIENT_SEARCH_LOCATORS: List[Tuple[str, str]] = [
    ("id", "header_secureTopMenu_lookup_txtLookup"),
    ("name", "header$secureTopMenu$lookup$txtLookup"),
    ("css", "input#header_secureTopMenu_lookup_txtLookup"),
    ("css", "input.SearchDefaultState"),
]

SEARCHRESULT_ROW_CSS = "tr.rgRow"  # SearchResults RadGrid rows

APPTS_TAB_XPATH = "//span[@data-celocalekey='Appts' or normalize-space()='Appts']"
VISITS_TABLE_ID = "ctl01_tblVisits"
VISIT_ROW_CSS = "tr.innerTableRow"

# Visit edit page controls (webhook trigger)
VISIT_SAVE_ID = "ctl01_btnSubmit"
VISIT_SAVE_XPATH = "//input[@type='submit' and @value='Save']"
VISIT_BACK_ID = "ctl01_btnCancel"
VISIT_BACK_XPATH = "//input[@type='button' and contains(@value, 'Back - Patient Administration')]"

VISIT_URL_SENTINEL = "page=Patients/Visit"

@dataclass
class RunConfig:
    mrn_csv: str
    max_visits_per_patient: int = 50
    login_grace_seconds: int = 300
    keep_browser_open: bool = False
    mode_label: str = "RUN"

def _wait(driver, seconds: int = 20):
    return WebDriverWait(driver, seconds)

def _locate_patient_search_box(driver, timeout: int) -> Optional[object]:
    end = time.time() + timeout
    last_err = None
    while time.time() < end:
        for kind, sel in PATIENT_SEARCH_LOCATORS:
            try:
                if kind == "id":
                    el = driver.find_element(By.ID, sel)
                elif kind == "name":
                    el = driver.find_element(By.NAME, sel)
                elif kind == "css":
                    el = driver.find_element(By.CSS_SELECTOR, sel)
                else:
                    continue
                if el.is_displayed():
                    return el
            except Exception as e:
                last_err = e
        time.sleep(1)
    if last_err:
        print(f"[ERROR] Patient search box not found. Last error: {last_err}")
    return None

def wait_for_manual_login(driver, grace_seconds: int) -> bool:
    print(f"[INFO] Waiting for manual login (grace {grace_seconds}s) ...")
    box = _locate_patient_search_box(driver, grace_seconds)
    if not box:
        print("[ERROR] Manual login grace expired without finding Patient Search box.")
        return False
    print("[INFO] Patient Search box detected. Proceeding.")
    return True

def read_mrns_deterministic(csv_path: str) -> List[str]:
    """
    Deterministic parsing:
    - If header row contains 'mrn' (case-insensitive), use that column.
    - Otherwise, use the first column of each non-empty row.
    """
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"MRN CSV not found: {csv_path}")

    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        sample = f.read(4096)
        f.seek(0)
        has_comma = "," in sample

        if has_comma:
            reader = csv.reader(f)
            rows = [r for r in reader if r and any(c.strip() for c in r)]
            if not rows:
                return []
            header = [c.strip() for c in rows[0]]
            mrn_idx = None
            for i, c in enumerate(header):
                if c.lower() == "mrn":
                    mrn_idx = i
                    break
            data_rows = rows[1:] if mrn_idx is not None else rows
            out = []
            for r in data_rows:
                if mrn_idx is not None:
                    val = r[mrn_idx] if mrn_idx < len(r) else ""
                else:
                    val = r[0]
                val = val.strip()
                if val:
                    out.append(val)
            return out
        else:
            # one MRN per line
            out = []
            for line in f:
                s = line.strip()
                if not s or s.startswith("#"):
                    continue
                out.append(s)
            return out

def patient_search_and_open_chart(driver, mrn: str) -> bool:
    box = _locate_patient_search_box(driver, timeout=20)
    if not box:
        print("[ERROR] Patient search box missing right before search.")
        return False

    try:
        box.clear()
    except Exception:
        pass
    box.click()
    box.send_keys(mrn)
    box.send_keys("\n")
    print(f"[INFO] Submitted MRN search: {mrn}")

    try:
        row = _wait(driver, 25).until(EC.presence_of_element_located((By.CSS_SELECTOR, SEARCHRESULT_ROW_CSS)))
        _wait(driver, 25).until(lambda d: row.is_displayed())
        ActionChains(driver).double_click(row).perform()
        print("[INFO] Opened patient chart via SearchResults double-click.")
        return True
    except TimeoutException:
        print("[ERROR] SearchResults row not found / not opened.")
        return False
    except WebDriverException as e:
        print(f"[ERROR] Failed to open chart from SearchResults: {e}")
        return False

def click_appts_tab(driver) -> bool:
    try:
        appts_span = _wait(driver, 20).until(EC.presence_of_element_located((By.XPATH, APPTS_TAB_XPATH)))
        appts_span.find_element(By.XPATH, "./ancestor-or-self::*[1]").click()
    except Exception:
        try:
            appts_span = driver.find_element(By.XPATH, APPTS_TAB_XPATH)
            appts_span.click()
        except Exception as e:
            print(f"[ERROR] Could not click Appts tab: {e}")
            return False

    try:
        _wait(driver, 20).until(EC.presence_of_element_located((By.ID, VISITS_TABLE_ID)))
        print("[INFO] Visits grid detected.")
        return True
    except TimeoutException:
        print("[ERROR] Visits grid not detected after Appts click.")
        return False

def _extract_visit_url(onclick: str, base_url: str) -> Optional[str]:
    """
    onclick format example:
        document.location='/Secure/.../default.aspx?page=Patients/Visit&pid=...&vid=...&action=e'
    """
    if not onclick:
        return None
    m = re.search(r"document\.location\s*=\s*'([^']+)'", onclick)
    if not m:
        return None
    rel = m.group(1)
    return urljoin(base_url, rel)

def _open_visit_by_row(driver, row) -> Optional[str]:
    base = driver.current_url
    onclick = row.get_attribute("onclick") or ""
    url = _extract_visit_url(onclick, base)
    if not url:
        print("[WARN] Visit row missing onclick URL; skipping row.")
        return None
    if VISIT_URL_SENTINEL not in url:
        print(f"[WARN] onclick URL does not look like Visit Edit: {url}")
        # still navigate; but verify before Save
    driver.get(url)
    return url

def _ensure_visit_edit_page(driver) -> bool:
    cur = driver.current_url or ""
    if VISIT_URL_SENTINEL not in cur:
        return False
    try:
        _wait(driver, 20).until(EC.presence_of_element_located((By.ID, VISIT_SAVE_ID)))
        return True
    except TimeoutException:
        return False

def _click_visit_save(driver) -> bool:
    try:
        btn = driver.find_element(By.ID, VISIT_SAVE_ID)
        btn.click()
        return True
    except Exception:
        try:
            driver.find_element(By.XPATH, VISIT_SAVE_XPATH).click()
            return True
        except Exception as e:
            print(f"[ERROR] Could not click Visit Save: {e}")
            return False

def _click_visit_back(driver) -> bool:
    try:
        driver.find_element(By.ID, VISIT_BACK_ID).click()
        return True
    except Exception:
        try:
            driver.find_element(By.XPATH, VISIT_BACK_XPATH).click()
            return True
        except Exception as e:
            print(f"[ERROR] Could not click Visit Back: {e}")
            return False

def process_visits_for_patient(driver, max_visits: int) -> int:
    """
    Assumes Visits grid is visible.
    Returns count of visits processed.
    """
    processed = 0
    # Re-fetch each loop because grid refreshes after Back
    while processed < max_visits:
        try:
            table = _wait(driver, 20).until(EC.presence_of_element_located((By.ID, VISITS_TABLE_ID)))
            rows = table.find_elements(By.CSS_SELECTOR, VISIT_ROW_CSS)
        except TimeoutException:
            print("[ERROR] Visits table/rows not found.")
            break

        if processed >= len(rows):
            break

        row = rows[processed]
        visit_url = _open_visit_by_row(driver, row)
        if not visit_url:
            processed += 1
            continue

        if not _ensure_visit_edit_page(driver):
            print(f"[ERROR] Not on Visit Edit page after navigation (processed={processed+1}). URL: {driver.current_url}")
            # Attempt to go back to chart + visits grid
            driver.back()
            time.sleep(1)
            processed += 1
            continue

        print(f"[INFO] Visit Edit confirmed. Saving... ({processed+1})")
        if not _click_visit_save(driver):
            processed += 1
            continue

        time.sleep(1.5)  # allow postback/webhook
        if not _click_visit_back(driver):
            processed += 1
            continue

        # Wait back to Visits grid
        try:
            _wait(driver, 25).until(EC.presence_of_element_located((By.ID, VISITS_TABLE_ID)))
        except TimeoutException:
            print("[WARN] Did not re-detect Visits grid after Back; continuing.")
        processed += 1

    return processed

def run_mrn_refresh(
    mrn_csv: str,
    max_visits_per_patient: int = 50,
    login_grace_seconds: int = 300,
    keep_browser_open: bool = False,
    mode_label: str = "RUN",
    start_url: str = None,
) -> None:
    cfg = RunConfig(
        mrn_csv=mrn_csv,
        max_visits_per_patient=max_visits_per_patient,
        login_grace_seconds=login_grace_seconds,
        keep_browser_open=keep_browser_open,
        mode_label=mode_label,
    )

    mrns = read_mrns_deterministic(cfg.mrn_csv)
    print(f"[INFO] Loaded {len(mrns)} MRN(s) from {cfg.mrn_csv}")

    driver = setup_driver()
    try:
        if start_url:
            driver.get(start_url)

        if not wait_for_manual_login(driver, cfg.login_grace_seconds):
            return

        for idx, mrn in enumerate(mrns, 1):
            print(f"\n=== [{idx}/{len(mrns)}] MRN {mrn} ===")
            ok = patient_search_and_open_chart(driver, mrn)
            if not ok:
                continue

            if not click_appts_tab(driver):
                continue

            count = process_visits_for_patient(driver, cfg.max_visits_per_patient)
            print(f"[INFO] Processed {count} visit(s) for MRN {mrn}")

    finally:
        if cfg.keep_browser_open:
            print("[INFO] keep_browser_open=True — leaving Chrome open.")
        else:
            try:
                driver.quit()
            except Exception:
                pass

# =======================================================================
# CHECKSUM FOOTER (auto-generated)
# SECTION_SHA256_FROZEN  = 45b6bdf0f4436402f3208740941456141ed92d306112abb14a602cb6bec5eab6
# SECTION_SHA256_MODULAR = 51fe5ae9931df324ac1d524c548e95d2b71c2b0e6d9f1fd91416125727adc880
# OVERALL_SHA256         = 4a97041b18a00d538d2e5e7ef84b1461cf48985b93d09310929572c82597a6ec
# =======================================================================
