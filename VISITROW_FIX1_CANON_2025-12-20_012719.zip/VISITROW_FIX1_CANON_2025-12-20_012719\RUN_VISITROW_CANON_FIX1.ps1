param(
  [Parameter(Mandatory=$true)][string]$Csv,
  [int]$MaxVisits = 50,
  [int]$LoginGraceSeconds = 300,
  [switch]$KeepBrowserOpen,
  [string]$Mode = "RUN",
  [string]$StartUrl = ""
)

$ErrorActionPreference = "Stop"

# Adjust if you keep these in a different folder
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

$py = "python"

$args = @(
  "counselear_visit_refresher_WRAPPER__CANON_VISITROW_FIX1.py",
  "--csv", $Csv,
  "--max-visits", $MaxVisits,
  "--login-grace-seconds", $LoginGraceSeconds,
  "--mode", $Mode
)

if ($KeepBrowserOpen) {
  $args += "--keep-browser-open"
}
if ($StartUrl -and $StartUrl.Trim().Length -gt 0) {
  $args += @("--start-url", $StartUrl)
}

Write-Host "Running: $py $($args -join ' ')"
& $py @args
