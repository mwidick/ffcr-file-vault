"""
Wrapper for CounselEAR Visit Refresher – CANON VISITROW FIX1

Purpose:
  - Parse CLI args
  - Call core.run_mrn_refresh(...)
"""

import argparse
import sys

import counselear_visit_refresher_core_v2_GoldCore__CANON_VISITROW_FIX1 as core

def build_arg_parser():
    p = argparse.ArgumentParser(description="CounselEAR Visit Refresher (CANON VISITROW FIX1)")
    p.add_argument("--csv", required=True, help="Path to MRN CSV (or one MRN per line text file).")
    p.add_argument("--max-visits", type=int, default=50, help="Max visits per patient (default 50).")
    p.add_argument("--login-grace-seconds", type=int, default=300, help="Seconds to allow for manual login.")
    p.add_argument("--keep-browser-open", action="store_true", help="Leave Chrome open at end.")
    p.add_argument("--mode", default="RUN", help="Mode label for logging.")
    p.add_argument("--start-url", default=None, help="Optional start URL (if you want the script to navigate first).")
    return p

def main(argv=None):
    args = build_arg_parser().parse_args(argv)
    core.run_mrn_refresh(
        mrn_csv=args.csv,
        max_visits_per_patient=args.max_visits,
        login_grace_seconds=args.login_grace_seconds,
        keep_browser_open=args.keep_browser_open,
        mode_label=args.mode,
        start_url=args.start_url,
    )

if __name__ == "__main__":
    main()

# =======================================================================
# CHECKSUM FOOTER (auto-generated)
# OVERALL_SHA256 = 0a5a8b00cf98580fd20cf7ae39d8fbbe81027f07c5271608f2f05b05beb1bdb2
# =======================================================================
