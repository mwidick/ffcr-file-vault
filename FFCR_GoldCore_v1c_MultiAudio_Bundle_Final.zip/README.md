# FFCR CounselEar Multi-Audiogram Extractor

This script automates the extraction of multiple audiograms from the CounselEar web interface. It is part of the FFCR (Fiber and Foam Chart Review) project.

## Features
- DOM-based extraction from the "Test Results" section.
- Supports multiple audiograms per patient.
- Uses Selenium and Pandas.
- Patient list must be in `counselear_patients.xlsx` with `patient_name` as the column header.
- Credentials loaded from `counselear_credentials.xlsx`.

## Usage

Launch using the batch file (example):
```
run_v1c_multi_audio_5_patients.bat
```

## SHA-256 Checksums

**Script:** `Ffcr_Counselear_GoldCore_v1c_MultiAudio_Annotated.py`  
**Full script checksum:** `7d287696d917a1b59d37717ba0ff1d8e9a99425987050b3905e2bdef9d1fd5a9`

Each section is also annotated with inline checksums in the script footer.

## Files
- `Ffcr_Counselear_GoldCore_v1c_MultiAudio_Annotated.py` — The main Python script.
- `counselear_patients.xlsx` — Patient input list.
- `counselear_credentials.xlsx` — Encrypted login info (must be provided separately).
- `run_v1c_multi_audio_5_patients.bat` — Sample batch launcher.
- `audiometry_data.xlsx` — Output Excel file with extracted audiograms.

## Notes

This package is designed for batch-mode audiometric analysis. It captures all available test data per patient, sorted into a single Excel spreadsheet with one row per audiogram instance.

