# FFCR Visit PDF Extractor v30.0d Patch 1h Final

This bundle contains the fully functional and validated version of the FFCR ModMed Visit PDF extractor with pagination override and multi-patient support via Excel.

## ✅ Key Features

- Mountaintop login logic (immutable lines 1–64)
- Reasserts pagination dropdown to 100 records per page
- Downloads visit PDFs for each MRN provided
- Loops through multiple patients from `mrn_input.xlsx`
- Fully validated in live test runs

## 🧾 Contents

- `ffcr_visit_pdf_extractor_v30_0d_patch1h_final.py`: Core script
- `ffcr_visit_pdf_extractor_v30_0d_patch1h_final.bat`: Batch launcher
- `mrn_input.xlsx`: Test MRNs (ending in 60 and 61)
- `log.txt`: Output log from latest test
- `manifest.txt`: Role description of each file
- `README.md`: This documentation file

## 🔧 Requirements

- Chrome v137 and matching ChromeDriver
- Python 3.10+ with `selenium` and `pandas`
- Folder structure should mirror: `C:\FFCR_Project\Banner\`

## 🧪 Launch Instructions

1. Double-click the `.bat` file to launch.
2. Chrome must be set to allow multiple downloads.
3. Ensure Excel and log files are writable.

## 🏷 GitHub Versioning

When uploading:
```bash
git add *
git commit -m "Add patch1h_final with working pagination and README"
git push origin main
git tag ffcr-v30.0d-patch1h-final
git push origin ffcr-v30.0d-patch1h-final
```

—

Preserved with the logic of the Mountain and the luck of the Scotty dog.