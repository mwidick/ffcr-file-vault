# FFCR Visit PDF Extractor - v30.0d_patch1h_final

## Summary
This bundle extracts visit PDFs from ModMed with pagination set to 100 and Excel-driven MRN looping.
It has passed all internal validations and uses the frozen Mountaintop login logic.

## Includes:
- ffcr_visit_pdf_extractor_v30_0d_patch1h_final.py
- ffcr_visit_pdf_extractor_v30_0d_patch1h_final.bat
- mrn_input.xlsx
- log.txt
- manifest.txt

## Requirements:
- Chrome v137 + ChromeDriver v137
- FFCR Project structure with folder: `C:\FFCR_Project\Banner`

## Launch Instructions:
Double-click the `.bat` file or run the `.py` script directly after validating Chrome and Python setup.
